import 'package:hive_flutter/hive_flutter.dart';
import 'package:chat_yemen/core/constants/app_constants.dart';
import 'package:chat_yemen/domain/entities/user.dart';
import 'package:chat_yemen/domain/entities/message.dart';

class HiveService {
  // الحصول على الصناديق
  Box<dynamic> get usersBox => Hive.box(AppConstants.usersBox);
  Box<dynamic> get messagesBox => Hive.box(AppConstants.messagesBox);
  Box<dynamic> get chatsBox => Hive.box(AppConstants.chatsBox);
  Box<dynamic> get transfersBox => Hive.box(AppConstants.transfersBox);
  
  // ==================== عمليات المستخدمين ====================
  
  Future<void> saveUser(User user) async {
    await usersBox.put(user.id, user.toJson());
  }
  
  User? getUser(String userId) {
    final data = usersBox.get(userId);
    if (data != null) {
      return User.fromJson(Map<String, dynamic>.from(data));
    }
    return null;
  }
  
  List<User> getAllUsers() {
    return usersBox.values
        .map((data) => User.fromJson(Map<String, dynamic>.from(data)))
        .toList();
  }
  
  List<User> getOnlineUsers() {
    return usersBox.values
        .where((data) => data['isOnline'] == true)
        .map((data) => User.fromJson(Map<String, dynamic>.from(data)))
        .toList();
  }

  Future<void> deleteUser(String userId) async {
    await usersBox.delete(userId);
  }
  
  Future<void> updateUserStatus(String userId, bool isOnline) async {
    final user = getUser(userId);
    if (user != null) {
      await saveUser(user.copyWith(
        isOnline: isOnline,
        lastSeen: isOnline ? null : DateTime.now(),
      ));
    }
  }
  
  // ==================== عمليات الرسائل ====================
  
  Future<void> saveMessage(Message message) async {
    await messagesBox.put(message.id, message.toJson());
  }
  
  Message? getMessage(String messageId) {
    final data = messagesBox.get(messageId);
    if (data != null) {
      return Message.fromJson(Map<String, dynamic>.from(data));
    }
    return null;
  }
  
  List<Message> getMessagesForChat(String chatId) {
    return messagesBox.values
        .where((data) {
          final msg = Message.fromJson(Map<String, dynamic>.from(data));
          return msg.chatId == chatId && !msg.isDeleted;
        })
        .map((data) => Message.fromJson(Map<String, dynamic>.from(data)))
        .toList()
      ..sort((a, b) => a.timestamp.compareTo(b.timestamp));
  }
  
  List<Message> getRecentMessages(int limit) {
    return messagesBox.values
        .where((data) => data['isDeleted'] == false)
        .map((data) => Message.fromJson(Map<String, dynamic>.from(data)))
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp))
      ..take(limit);
  }
  
  Future<void> deleteMessage(String messageId) async {
    final message = getMessage(messageId);
    if (message != null) {
      await saveMessage(message.copyWith(isDeleted: true));
    }
  }
  
  Future<void> deleteMessagePermanently(String messageId) async {
    await messagesBox.delete(messageId);
  }
  
  Future<void> updateMessageStatus(String messageId, MessageStatus status) async {
    final message = getMessage(messageId);
    if (message != null) {
      await saveMessage(message.copyWith(status: status));
    }
  }
  
  // ==================== عمليات الملفات غير المكتملة ====================
  
  Future<void> saveTransfer(String transferId, Map<String, dynamic> data) async {
    await transfersBox.put(transferId, data);
  }
  
  Map<String, dynamic>? getTransfer(String transferId) {
    final data = transfersBox.get(transferId);
    if (data != null) {
      return Map<String, dynamic>.from(data);
    }
    return null;
  }
  
  List<Map<String, dynamic>> getPendingTransfers() {
    return transfersBox.values
        .where((data) => data['status'] == 'pending')
        .map((data) => Map<String, dynamic>.from(data))
        .toList();
  }
  
  Future<void> deleteTransfer(String transferId) async {
    await transfersBox.delete(transferId);
  }
  
  // ==================== عمليات المحادثات ====================
  
  Future<void> saveChat(String chatId, Map<String, dynamic> data) async {
    await chatsBox.put(chatId, data);
  }
  
  Map<String, dynamic>? getChat(String chatId) {
    final data = chatsBox.get(chatId);
    if (data != null) {
      return Map<String, dynamic>.from(data);
    }
    return null;
  }
  
  List<Map<String, dynamic>> getAllChats() {
    return chatsBox.values
        .map((data) => Map<String, dynamic>.from(data))
        .toList()
      ..sort((a, b) => (b['lastMessageTime'] ?? '').compareTo(a['lastMessageTime'] ?? ''));
  }
  
  Future<void> deleteChat(String chatId) async {
    await chatsBox.delete(chatId);
  }
}
