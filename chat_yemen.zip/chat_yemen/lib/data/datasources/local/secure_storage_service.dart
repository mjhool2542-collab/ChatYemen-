import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageService {
  static const String _userIdKey = 'user_id';
  static const String _privateKeyKey = 'private_key';
  static const String _publicKeyKey = 'public_key';
  static const String _themeModeKey = 'theme_mode';
  
  final FlutterSecureStorage _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(
      encryptedSharedPreferences: true,
    ),
  );
  
  // ==================== إدارة المستخدم ====================
  
  Future<void> saveUserId(String userId) async {
    await _storage.write(key: _userIdKey, value: userId);
  }
  
  Future<String?> getUserId() async {
    return await _storage.read(key: _userIdKey);
  }
  
  Future<void> deleteUserId() async {
    await _storage.delete(key: _userIdKey);
  }
  
  // ==================== إدارة المفاتيح ====================
  
  Future<void> savePrivateKey(String privateKey) async {
    await _storage.write(key: _privateKeyKey, value: privateKey);
  }
  
  Future<String?> getPrivateKey() async {
    return await _storage.read(key: _privateKeyKey);
  }
  
  Future<void> savePublicKey(String publicKey) async {
    await _storage.write(key: _publicKeyKey, value: publicKey);
  }
  
  Future<String?> getPublicKey() async {
    return await _storage.read(key: _publicKeyKey);
  }
  
  // ==================== إعدادات التطبيق ====================
  
  Future<void> saveThemeMode(String themeMode) async {
    await _storage.write(key: _themeModeKey, value: themeMode);
  }
  
  Future<String?> getThemeMode() async {
    return await _storage.read(key: _themeModeKey);
  }
  
  // ==================== مسح البيانات ====================
  
  Future<void> clearAll() async {
    await _storage.deleteAll();
  }
}
