import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:chat_yemen/services/wifi_direct_service.dart';
import 'package:chat_yemen/core/enums/connection_status.dart';

class WiFiNotifier extends StateNotifier<WiFiState> {
  final WiFiDirectService _wifiService = WiFiDirectService();
  
  WiFiNotifier() : super(WiFiState.initial()) {
    _initialize();
  }
  
  Future<void> _initialize() async {
    await _wifiService.initialize();
    state = state.copyWith(status: ConnectionStatus.disconnected);
    
    _wifiService.connectionStream.listen((event) {
      if (event['status'] == 'connected') {
        state = state.copyWith(
          status: ConnectionStatus.connected,
          ipAddress: event['ip'],
          connectedDevice: event['device'],
        );
      } else {
        state = state.copyWith(
          status: ConnectionStatus.disconnected,
          ipAddress: null,
          connectedDevice: null,
        );
      }
    });
  }
  
  // ==================== إنشاء مجموعة ====================
  
  Future<bool> createGroup(String name) async {
    state = state.copyWith(status: ConnectionStatus.connecting);
    final success = await _wifiService.createGroup(name);
    if (success) {
      state = state.copyWith(status: ConnectionStatus.connected);
    } else {
      state = state.copyWith(status: ConnectionStatus.error);
    }
    return success;
  }
  
  // ==================== البحث عن أجهزة ====================
  
  Future<void> discoverDevices() async {
    state = state.copyWith(isDiscovering: true);
    await _wifiService.discoverDevices();
    
    _wifiService.deviceStream.listen((devices) {
      state = state.copyWith(devices: devices);
    });
  }
  
  Future<void> stopDiscovery() async {
    await _wifiService.stopDiscovery();
    state = state.copyWith(isDiscovering: false);
  }
  
  // ==================== الاتصال بجهاز ====================
  
  Future<bool> connectToDevice(String deviceAddress) async {
    state = state.copyWith(status: ConnectionStatus.connecting);
    final success = await _wifiService.connectToDevice(deviceAddress);
    if (success) {
      state = state.copyWith(status: ConnectionStatus.connected);
    } else {
      state = state.copyWith(status: ConnectionStatus.error);
    }
    return success;
  }
  
  // ==================== فصل الاتصال ====================
  
  Future<void> disconnect() async {
    await _wifiService.disconnect();
    state = state.copyWith(
      status: ConnectionStatus.disconnected,
      ipAddress: null,
      connectedDevice: null,
    );
  }
  
  // ==================== تنظيف ====================
  
  @override
  void dispose() {
    _wifiService.dispose();
    super.dispose();
  }
}

// ==================== حالة WiFi ====================

class WiFiState {
  final ConnectionStatus status;
  final bool isDiscovering;
  final String? ipAddress;
  final String? connectedDevice;
  final List<Map<String, dynamic>> devices;
  
  WiFiState({
    required this.status,
    this.isDiscovering = false,
    this.ipAddress,
    this.connectedDevice,
    this.devices = const [],
  });
  
  WiFiState.initial()
      : status = ConnectionStatus.disconnected,
        isDiscovering = false,
        ipAddress = null,
        connectedDevice = null,
        devices = const [];
  
  WiFiState copyWith({
    ConnectionStatus? status,
    bool? isDiscovering,
    String? ipAddress,
    String? connectedDevice,
    List<Map<String, dynamic>>? devices,
  }) {
    return WiFiState(
      status: status ?? this.status,
      isDiscovering: isDiscovering ?? this.isDiscovering,
      ipAddress: ipAddress ?? this.ipAddress,
      connectedDevice: connectedDevice ?? this.connectedDevice,
      devices: devices ?? this.devices,
    );
  }
}

final wifiProvider = StateNotifierProvider<WiFiNotifier, WiFiState>((ref) {
  return WiFiNotifier();
});
