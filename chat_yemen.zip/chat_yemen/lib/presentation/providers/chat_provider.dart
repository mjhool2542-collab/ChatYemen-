import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:chat_yemen/domain/entities/message.dart';
import 'package:chat_yemen/data/datasources/local/hive_service.dart';

class ChatNotifier extends StateNotifier<List<Message>> {
  final HiveService _hiveService;
  final String _chatId;
  Timer? _refreshTimer;
  
  ChatNotifier(this._hiveService, this._chatId) : super([]) {
    _loadMessages();
    _startAutoRefresh();
  }
  
  // ==================== تحميل الرسائل ====================
  
  void _loadMessages() {
    state = _hiveService.getMessagesForChat(_chatId);
  }
  
  void refresh() {
    _loadMessages();
  }
  
  // ==================== تحديث تلقائي ====================
  
  void _startAutoRefresh() {
    _refreshTimer = Timer.periodic(
      const Duration(seconds: 2),
      (_) => _loadMessages(),
    );
  }
  
  // ==================== إرسال رسالة ====================
  
  Future<void> sendMessage(Message message) async {
    try {
      await _hiveService.saveMessage(message);
      
      // تحديث المحادثة
      await _updateChat(message);
      
      _loadMessages();
    } catch (e) {
      print('Error sending message: $e');
    }
  }
  
  // ==================== تحديث المحادثة ====================
  
  Future<void> _updateChat(Message message) async {
    final chat = _hiveService.getChat(_chatId) ?? {};
    chat['lastMessage'] = message.content;
    chat['lastMessageTime'] = message.timestamp.toIso8601String();
    chat['lastMessageSender'] = message.senderId;
    chat['unreadCount'] = (chat['unreadCount'] ?? 0) + 1;
    
    await _hiveService.saveChat(_chatId, chat);
  }
  
  // ==================== تحديث حالة الرسالة ====================
  
  Future<void> markAsRead(String messageId) async {
    await _hiveService.updateMessageStatus(messageId, MessageStatus.read);
    _loadMessages();
  }
  
  Future<void> markAllAsRead() async {
    for (final message in state) {
      if (message.status != MessageStatus.read) {
        await _hiveService.updateMessageStatus(message.id, MessageStatus.read);
      }
    }
    _loadMessages();
  }
  
  // ==================== حذف رسالة ====================
  
  Future<void> deleteMessage(String messageId) async {
    await _hiveService.deleteMessage(messageId);
    _loadMessages();
  }
  
  Future<void> deleteMessageForEveryone(String messageId) async {
    // في وضع Offline، حذف للجميع يعني حذفها من الجهازين
    // سيتم تنفيذ هذا لاحقاً عبر Wi-Fi Direct
    await _hiveService.deleteMessagePermanently(messageId);
    _loadMessages();
  }
  
  // ==================== تنظيف ====================
  
  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }
}

final chatProviderFamily = StateNotifierProvider.family<ChatNotifier, List<Message>, String>((ref, chatId) {
  return ChatNotifier(HiveService(), chatId);
});
