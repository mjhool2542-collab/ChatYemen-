import 'dart:developer';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:chat_yemen/domain/entities/user.dart';
import 'package:chat_yemen/data/datasources/local/hive_service.dart';
import 'package:chat_yemen/data/datasources/local/secure_storage_service.dart';
import 'package:chat_yemen/services/encryption_service.dart';
import 'package:uuid/uuid.dart';

class AuthNotifier extends StateNotifier<User?> {
  final SecureStorageService _secureStorage;
  final HiveService _hiveService;
  
  AuthNotifier(this._secureStorage, this._hiveService) : super(null);
  
  // ==================== التحقق من الهوية ====================
  
  Future<void> checkIdentity() async {
    try {
      final userId = await _secureStorage.getUserId();
      if (userId != null) {
        final user = _hiveService.getUser(userId);
        if (user != null) {
          log('✅ User found: ${user.name}');
          state = user;
          return;
        }
        await _secureStorage.deleteUserId();
      }
      state = null;
    } catch (e) {
      log('❌ Error checking identity: $e');
      state = null;
    }
  }
  
  // ==================== إنشاء هوية جديدة ====================
  
  Future<void> createIdentity(String name, String? avatarPath) async {
    try {
      final userId = const Uuid().v4();
      
      // توليد مفاتيح التشفير
      final privateKey = EncryptionService.generateKey();
      final publicKey = EncryptionService.generateKey();
      
      await _secureStorage.savePrivateKey(privateKey);
      await _secureStorage.savePublicKey(publicKey);
      
      final user = User(
        id: userId,
        name: name.trim(),
        avatarPath: avatarPath,
        isOnline: true,
        publicKey: publicKey,
        lastSeen: DateTime.now(),
      );
      
      await _hiveService.saveUser(user);
      await _secureStorage.saveUserId(userId);
      
      log('✅ Identity created: ${user.name}');
      state = user;
    } catch (e) {
      log('❌ Error creating identity: $e');
      rethrow;
    }
  }
  
  // ==================== تحديث المستخدم ====================
  
  Future<void> updateUser(User user) async {
    try {
      await _hiveService.saveUser(user);
      state = user;
    } catch (e) {
      log('❌ Error updating user: $e');
      rethrow;
    }
  }
  
  // ==================== تحديث الحالة ====================
  
  Future<void> setOnline(bool isOnline) async {
    if (state != null) {
      final updated = state!.copyWith(
        isOnline: isOnline,
        lastSeen: isOnline ? null : DateTime.now(),
      );
      await _hiveService.saveUser(updated);
      state = updated;
    }
  }
  
  // ==================== تسجيل الخروج ====================
  
  Future<void> logout() async {
    try {
      if (state != null) {
        await setOnline(false);
      }
      await _secureStorage.deleteUserId();
      state = null;
      log('👋 User logged out');
    } catch (e) {
      log('❌ Error logging out: $e');
    }
  }
  
  // ==================== حذف الحساب ====================
  
  Future<void> deleteAccount() async {
    try {
      if (state != null) {
        await _hiveService.deleteUser(state!.id);
        await _secureStorage.clearAll();
        state = null;
      }
    } catch (e) {
      log('❌ Error deleting account: $e');
    }
  }
}

final authProvider = StateNotifierProvider<AuthNotifier, User?>((ref) {
  return AuthNotifier(SecureStorageService(), HiveService());
});
