import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:chat_yemen/core/constants/app_colors.dart';
import 'package:chat_yemen/domain/entities/message.dart';
import 'package:chat_yemen/domain/entities/user.dart';
import 'package:chat_yemen/presentation/providers/auth_provider.dart';
import 'package:chat_yemen/presentation/providers/chat_provider.dart';
import 'package:chat_yemen/presentation/providers/wifi_provider.dart';

class ChatScreen extends ConsumerStatefulWidget {
  final String userId;
  final String userName;
  final String? deviceIp;
  
  const ChatScreen({
    super.key,
    required this.userId,
    required this.userName,
    this.deviceIp,
  });
  
  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  
  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }
  
  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }
  
  void _sendMessage() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    
    final user = ref.read(authProvider);
    if (user == null) return;
    
    final message = Message(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      chatId: widget.userId,
      senderId: user.id,
      receiverId: widget.userId,
      type: MessageType.text,
      content: text,
      timestamp: DateTime.now(),
      status: MessageStatus.sent,
    );
    
    ref.read(chatProviderFamily(widget.userId).notifier).sendMessage(message);
    _controller.clear();
    _scrollToBottom();
  }
  
  Future<void> _pickFile() async {
    try {
      final result = await FilePicker.platform.pickFiles();
      if (result != null && result.files.single.path != null) {
        final file = result.files.single;
        final user = ref.read(authProvider);
        if (user == null) return;
        
        final message = Message(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          chatId: widget.userId,
          senderId: user.id,
          receiverId: widget.userId,
          type: MessageType.file,
          content: file.name,
          filePath: file.path,
          fileSize: file.size,
          timestamp: DateTime.now(),
          status: MessageStatus.sent,
        );
        
        ref.read(chatProviderFamily(widget.userId).notifier).sendMessage(message);
        _scrollToBottom();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ في اختيار الملف: $e')),
      );
    }
  }
  
  Future<void> _pickImage() async {
    try {
      final picker = ImagePicker();
      final image = await picker.pickImage(source: ImageSource.gallery);
      
      if (image != null) {
        final user = ref.read(authProvider);
        if (user == null) return;
        
        final message = Message(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          chatId: widget.userId,
          senderId: user.id,
          receiverId: widget.userId,
          type: MessageType.image,
          content: 'صورة',
          filePath: image.path,
          fileSize: await File(image.path).length(),
          timestamp: DateTime.now(),
          status: MessageStatus.sent,
        );
        
        ref.read(chatProviderFamily(widget.userId).notifier).sendMessage(message);
        _scrollToBottom();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ في اختيار الصورة: $e')),
      );
    }
  }
  
  Widget _buildMessageBubble(Message message, User? currentUser) {
    final isMe = message.senderId == currentUser?.id;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 10,
              ),
              decoration: BoxDecoration(
                color: isMe 
                    ? AppColors.lightMyMessage 
                    : AppColors.lightOtherMessage,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _buildMessageContent(message),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '${message.timestamp.hour.toString().padLeft(2, '0')}:'
                        '${message.timestamp.minute.toString().padLeft(2, '0')}',
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.grey[600],
                        ),
                      ),
                      const SizedBox(width: 4),
                      if (isMe)
                        Icon(
                          message.status == MessageStatus.sent 
                              ? Icons.check 
                              : Icons.check_circle,
                          size: 14,
                          color: message.status == MessageStatus.sent 
                              ? Colors.grey 
                              : AppColors.primary,
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildMessageContent(Message message) {
    switch (message.type) {
      case MessageType.text:
        return Text(
          message.content,
          style: const TextStyle(fontSize: 14),
        );
      case MessageType.image:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (message.filePath != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(
                  File(message.filePath!),
                  width: 200,
                  height: 150,
                  fit: BoxFit.cover,
                ),
              ),
            const SizedBox(height: 4),
            Text(
              '🖼️ صورة',
              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            ),
          ],
        );
      case MessageType.file:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.insert_drive_file, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    message.content,
                    style: const TextStyle(fontSize: 14),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            if (message.fileSize != null)
              Text(
                _formatFileSize(message.fileSize!),
                style: TextStyle(fontSize: 10, color: Colors.grey[600]),
              ),
          ],
        );
      default:
        return Text(message.content);
    }
  }
  
  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
  
  @override
  Widget build(BuildContext context) {
    final messages = ref.watch(chatProviderFamily(widget.userId));
    final currentUser = ref.watch(authProvider);
    final wifiState = ref.watch(wifiProvider);
    
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: Colors.white.withOpacity(0.2),
              child: Text(
                widget.userName.isNotEmpty ? widget.userName[0].toUpperCase() : '?',
                style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.userName, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: wifiState.status.isConnected ? AppColors.online : AppColors.offline,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(wifiState.status.isConnected ? 'متصل' : 'غير متصل', style: const TextStyle(fontSize: 10, color: Colors.white70)),
                  ],
                ),
              ],
            ),
          ],
        ),
        backgroundColor: AppColors.primary,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(12),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                return _buildMessageBubble(messages[index], currentUser);
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: const BoxDecoration(color: Colors.white),
            child: Row(
              children: [
                IconButton(icon: const Icon(Icons.attach_file, color: AppColors.primary), onPressed: _pickFile),
                IconButton(icon: const Icon(Icons.image, color: AppColors.primary), onPressed: _pickImage),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'اكتب رسالة...',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none),
                      filled: true,
                      fillColor: Colors.grey[100],
                    ),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                IconButton(icon: const Icon(Icons.send, color: AppColors.primary), onPressed: _sendMessage),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
