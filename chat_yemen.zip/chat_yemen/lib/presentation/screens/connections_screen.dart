import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:chat_yemen/core/constants/app_colors.dart';
import 'package:chat_yemen/core/enums/connection_status.dart';
import 'package:chat_yemen/domain/entities/user.dart';
import 'package:chat_yemen/presentation/providers/auth_provider.dart';
import 'package:chat_yemen/presentation/providers/wifi_provider.dart';
import 'package:chat_yemen/presentation/screens/chat_screen.dart';

class ConnectionsScreen extends ConsumerStatefulWidget {
  const ConnectionsScreen({super.key});
  
  @override
  ConsumerState<ConnectionsScreen> createState() => _ConnectionsScreenState();
}

class _ConnectionsScreenState extends ConsumerState<ConnectionsScreen> {
  final TextEditingController _searchController = TextEditingController();
  
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(wifiProvider.notifier).discoverDevices();
    });
  }
  
  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider);
    final wifiState = ref.watch(wifiProvider);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'المتصلون',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: AppColors.primary,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline, color: Colors.white),
            onPressed: _showUserProfile,
          ),
        ],
      ),
      body: Column(
        children: [
          // شريط البحث والمسح
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: 'بحث عن جهاز...',
                      hintStyle: TextStyle(color: Colors.grey[400]),
                      prefixIcon: const Icon(Icons.search, color: Colors.grey),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: Colors.grey[100],
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                    ),
                    onChanged: (value) {
                      // فلتر الأجهزة
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  decoration: BoxDecoration(
                    color: wifiState.isDiscovering 
                        ? Colors.grey 
                        : AppColors.primary,
                    shape: BoxShape.circle,
                  ),
                  child: IconButton(
                    icon: Icon(
                      wifiState.isDiscovering 
                          ? Icons.stop 
                          : Icons.refresh,
                      color: Colors.white,
                      size: 22,
                    ),
                    onPressed: wifiState.isDiscovering 
                        ? () => ref.read(wifiProvider.notifier).stopDiscovery()
                        : () => ref.read(wifiProvider.notifier).discoverDevices(),
                  ),
                ),
              ],
            ),
          ),
          
          // حالة الاتصال
          _buildConnectionStatus(user, wifiState),
          
          const SizedBox(height: 8),
          
          // قائمة الأجهزة
          Expanded(
            child: wifiState.isDiscovering
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(),
                        SizedBox(height: 16),
                        Text('جاري البحث عن أجهزة قريبة...'),
                      ],
                    ),
                  )
                : wifiState.devices.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.wifi_off,
                              size: 60,
                              color: Colors.grey,
                            ),
                            SizedBox(height: 16),
                            Text(
                              'لا توجد أجهزة قريبة',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'تأكد من تشغيل Wi-Fi على الجهاز الآخر',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        itemCount: wifiState.devices.length,
                        itemBuilder: (context, index) {
                          final device = wifiState.devices[index];
                          return _buildDeviceCard(device);
                        },
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showCreateGroupDialog(),
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.group_add, color: Colors.white),
      ),
    );
  }
  
  // ==================== بناء بطاقة الجهاز ====================
  
  Widget _buildDeviceCard(Map<String, dynamic> device) {
    final isOnline = device['isOnline'] ?? false;
    final name = device['name'] ?? 'جهاز غير معروف';
    final address = device['address'] ?? '';
    
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: isOnline ? AppColors.primary : Colors.grey[300],
          child: Text(
            name.isNotEmpty ? name[0].toUpperCase() : '?',
            style: const TextStyle(color: Colors.white),
          ),
        ),
        title: Text(
          name,
          style: const TextStyle(fontWeight: FontWeight.w500),
        ),
        subtitle: Row(
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: isOnline ? AppColors.online : AppColors.offline,
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 6),
            Text(
              isOnline ? 'متصل' : 'غير متصل',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(width: 12),
            Text(
              address,
              style: TextStyle(
                fontSize: 10,
                color: Colors.grey[400],
              ),
            ),
          ],
        ),
        trailing: isOnline
            ? ElevatedButton(
                onPressed: () {
                  _startChat(device);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                ),
                child: const Text(
                  'دردشة',
                  style: TextStyle(color: Colors.white),
                ),
              )
            : Icon(
                Icons.wifi_off,
                color: Colors.grey[400],
              ),
      ),
    );
  }
  
  // ==================== حالة الاتصال ====================
  
  Widget _buildConnectionStatus(User? user, WiFiState wifiState) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: wifiState.status.color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: wifiState.status.color.withOpacity(0.2),
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 18,
            backgroundColor: wifiState.status.color.withOpacity(0.2),
            child: Icon(
              wifiState.status.isConnected ? Icons.wifi : Icons.wifi_off,
              size: 20,
              color: wifiState.status.color,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  wifiState.status.message,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: wifiState.status.color,
                  ),
                ),
                if (wifiState.ipAddress != null)
                  Text(
                    'IP: ${wifiState.ipAddress}',
                    style: TextStyle(
                      fontSize: 11,
                      color: Colors.grey[600],
                    ),
                  ),
              ],
            ),
          ),
          if (wifiState.status.isConnected)
            IconButton(
              icon: const Icon(Icons.exit_to_app, color: Colors.red),
              onPressed: () => ref.read(wifiProvider.notifier).disconnect(),
            ),
        ],
      ),
    );
  }
  
  // ==================== بدء الدردشة ====================
  
  void _startChat(Map<String, dynamic> device) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          userId: device['address'] ?? device['id'],
          userName: device['name'] ?? 'جهاز غير معروف',
          deviceIp: device['ip'],
        ),
      ),
    );
  }
  
  // ==================== عرض الملف الشخصي ====================
  
  void _showUserProfile() {
    final user = ref.read(authProvider);
    if (user != null) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('الملف الشخصي'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 40,
                backgroundColor: AppColors.primary,
                child: Text(
                  user.name[0].toUpperCase(),
                  style: const TextStyle(fontSize: 30, color: Colors.white),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                user.name,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                'ID: ${user.id.substring(0, 8)}',
                style: TextStyle(fontSize: 12, color: Colors.grey[600]),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: user.isOnline ? AppColors.online : AppColors.offline,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    user.isOnline ? 'متصل' : 'غير متصل',
                    style: TextStyle(
                      fontSize: 12,
                      color: user.isOnline ? AppColors.online : Colors.grey,
                    ),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                ref.read(authProvider.notifier).logout();
                Navigator.pop(context);
              },
              child: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إغلاق'),
            ),
          ],
        ),
      );
    }
  }
  
  // ==================== إنشاء مجموعة ====================
  
  void _showCreateGroupDialog() {
    final TextEditingController nameController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إنشاء مجموعة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'يمكنك إنشاء مجموعة للاتصال بأجهزة متعددة',
              style: TextStyle(fontSize: 14, color: Colors.grey[600]),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                hintText: 'اسم المجموعة',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              final name = nameController.text.trim();
              if (name.isNotEmpty) {
                ref.read(wifiProvider.notifier).createGroup(name);
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
            ),
            child: const Text('إنشاء', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
