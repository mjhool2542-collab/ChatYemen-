import 'dart:convert';
import 'dart:math';
import 'package:cryptography/cryptography.dart';

class EncryptionService {
  // توليد مفتاح عشوائي
  static String generateKey() {
    final random = Random.secure();
    final bytes = List<int>.generate(32, (_) => random.nextInt(256));
    return base64.encode(bytes);
  }
  
  // تشفير نص
  static Future<String> encryptText(String text, String key) async {
    try {
      final keyBytes = base64.decode(key);
      final algorithm = AesCbcWithPkcs7(
        key: SecretKey(keyBytes),
      );
      
      final iv = algorithm.newNonce();
      final secretKey = SecretKey(keyBytes);
      
      final encrypted = await algorithm.encrypt(
        utf8.encode(text),
        secretKey: secretKey,
        nonce: iv,
      );
      
      final combined = <int>[];
      combined.addAll(iv.bytes);
      combined.addAll(encrypted.cipherText);
      
      return base64.encode(combined);
    } catch (e) {
      return text; // في حالة الخطأ، نرسل النص بدون تشفير
    }
  }
  
  // فك تشفير نص
  static Future<String> decryptText(String encryptedText, String key) async {
    try {
      final keyBytes = base64.decode(key);
      final combined = base64.decode(encryptedText);
      
      // أول 16 بايت هي IV
      final iv = combined.take(16).toList();
      final cipherText = combined.skip(16).toList();
      
      final algorithm = AesCbcWithPkcs7(
        key: SecretKey(keyBytes),
      );
      
      final decrypted = await algorithm.decrypt(
        cipherText,
        secretKey: SecretKey(keyBytes),
        nonce: Nonce(iv),
      );
      
      return utf8.decode(decrypted);
    } catch (e) {
      return encryptedText; // إذا فشل فك التشفير، نرجع النص المشفر
    }
  }
  
  // تشفير ملف
  static Future<List<int>> encryptFile(List<int> fileData, String key) async {
    try {
      final keyBytes = base64.decode(key);
      final algorithm = AesCbcWithPkcs7(
        key: SecretKey(keyBytes),
      );
      
      final iv = algorithm.newNonce();
      final secretKey = SecretKey(keyBytes);
      
      final encrypted = await algorithm.encrypt(
        fileData,
        secretKey: secretKey,
        nonce: iv,
      );
      
      final combined = <int>[];
      combined.addAll(iv.bytes);
      combined.addAll(encrypted.cipherText);
      
      return combined;
    } catch (e) {
      return fileData;
    }
  }
  
  // فك تشفير ملف
  static Future<List<int>> decryptFile(List<int> encryptedData, String key) async {
    try {
      final keyBytes = base64.decode(key);
      
      // أول 16 بايت هي IV
      final iv = encryptedData.take(16).toList();
      final cipherText = encryptedData.skip(16).toList();
      
      final algorithm = AesCbcWithPkcs7(
        key: SecretKey(keyBytes),
      );
      
      final decrypted = await algorithm.decrypt(
        cipherText,
        secretKey: SecretKey(keyBytes),
        nonce: Nonce(iv),
      );
      
      return decrypted;
    } catch (e) {
      return encryptedData;
    }
  }
}
