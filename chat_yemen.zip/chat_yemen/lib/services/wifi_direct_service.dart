import 'dart:async';
import 'package:flutter/services.dart';

class WiFiDirectService {
  static final WiFiDirectService _instance = WiFiDirectService._internal();
  factory WiFiDirectService() => _instance;
  WiFiDirectService._internal();
  
  final MethodChannel _channel = const MethodChannel('wifi_direct_plugin');
  
  // حالة الاتصال
  bool _isHost = false;
  bool _isConnected = false;
  String? _deviceName;
  String? _ipAddress;
  
  // Streams
  final _deviceStreamController = StreamController<List<Map<String, dynamic>>>.broadcast();
  final _connectionStreamController = StreamController<Map<String, dynamic>>.broadcast();
  
  Stream<List<Map<String, dynamic>>> get deviceStream => _deviceStreamController.stream;
  Stream<Map<String, dynamic>> get connectionStream => _connectionStreamController.stream;
  
  bool get isConnected => _isConnected;
  bool get isHost => _isHost;
  String? get ipAddress => _ipAddress;
  
  // ==================== تهيئة ====================
  
  Future<void> initialize() async {
    try {
      await _channel.invokeMethod('initialize');
      
      _channel.setMethodCallHandler((call) async {
        switch (call.method) {
          case 'onDeviceFound':
            _deviceStreamController.add([call.arguments]);
            break;
          case 'onDevicesUpdated':
            _deviceStreamController.add(call.arguments.cast<Map<String, dynamic>>());
            break;
          case 'onConnected':
            _isConnected = true;
            _ipAddress = call.arguments['ip'];
            _connectionStreamController.add({
              'status': 'connected',
              'ip': _ipAddress,
              'device': call.arguments['device'],
            });
            break;
          case 'onDisconnected':
            _isConnected = false;
            _ipAddress = null;
            _connectionStreamController.add({
              'status': 'disconnected',
            });
            break;
        }
      });
    } catch (e) {
      print('WiFiDirect initialization error: $e');
    }
  }
  
  // ==================== إنشاء مجموعة ====================
  
  Future<bool> createGroup(String name) async {
    try {
      final result = await _channel.invokeMethod('createGroup', {
        'name': name,
      });
      _isHost = true;
      _isConnected = true;
      _deviceName = name;
      _ipAddress = result['ip'];
      return true;
    } catch (e) {
      print('Create group error: $e');
      return false;
    }
  }
  
  // ==================== البحث عن أجهزة ====================
  
  Future<void> discoverDevices() async {
    try {
      await _channel.invokeMethod('discoverDevices');
    } catch (e) {
      print('Discover devices error: $e');
    }
  }
  
  Future<void> stopDiscovery() async {
    try {
      await _channel.invokeMethod('stopDiscovery');
    } catch (e) {
      print('Stop discovery error: $e');
    }
  }
  
  // ==================== الاتصال بجهاز ====================
  
  Future<bool> connectToDevice(String deviceAddress) async {
    try {
      final result = await _channel.invokeMethod('connectToDevice', {
        'address': deviceAddress,
      });
      _isConnected = true;
      _ipAddress = result['ip'];
      return true;
    } catch (e) {
      print('Connect to device error: $e');
      return false;
    }
  }
  
  // ==================== فصل الاتصال ====================
  
  Future<void> disconnect() async {
    try {
      await _channel.invokeMethod('disconnect');
      _isConnected = false;
      _isHost = false;
      _ipAddress = null;
    } catch (e) {
      print('Disconnect error: $e');
    }
  }
  
  // ==================== إرسال بيانات ====================
  
  Future<void> sendData(String ip, int port, String data) async {
    try {
      await _channel.invokeMethod('sendData', {
        'ip': ip,
        'port': port,
        'data': data,
      });
    } catch (e) {
      print('Send data error: $e');
    }
  }
  
  // ==================== إرسال ملف ====================
  
  Future<void> sendFile(String ip, int port, String filePath) async {
    try {
      await _channel.invokeMethod('sendFile', {
        'ip': ip,
        'port': port,
        'path': filePath,
      });
    } catch (e) {
      print('Send file error: $e');
    }
  }
  
  // ==================== تنظيف ====================
  
  void dispose() {
    _deviceStreamController.close();
    _connectionStreamController.close();
  }
}
