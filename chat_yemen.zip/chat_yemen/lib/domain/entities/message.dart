import 'package:equatable/equatable.dart';

enum MessageType { 
  text, 
  image, 
  video, 
  audio, 
  file, 
  sticker,
  system,
  public_broadcast // ميزة FireChat للبث العام
}

enum MessageStatus { 
  sending, 
  sent, 
  delivered, 
  read, 
  failed 
}

class Message extends Equatable {
  final String id;
  final String chatId;
  final String senderId;
  final String receiverId;
  final MessageType type;
  final String content;
  final String? filePath;
  final int? fileSize;
  final String? thumbnailPath;
  final DateTime timestamp;
  final MessageStatus status;
  final bool isDeleted;
  final bool isForwarded;
  final String? replyToId;
  
  const Message({
    required this.id,
    required this.chatId,
    required this.senderId,
    required this.receiverId,
    required this.type,
    required this.content,
    this.filePath,
    this.fileSize,
    this.thumbnailPath,
    required this.timestamp,
    this.status = MessageStatus.sent,
    this.isDeleted = false,
    this.isForwarded = false,
    this.replyToId,
  });
  
  @override
  List<Object?> get props => [
    id, chatId, senderId, receiverId, type, content, 
    filePath, fileSize, thumbnailPath, timestamp, status, 
    isDeleted, isForwarded, replyToId
  ];
  
  Message copyWith({
    String? id,
    String? chatId,
    String? senderId,
    String? receiverId,
    MessageType? type,
    String? content,
    String? filePath,
    int? fileSize,
    String? thumbnailPath,
    DateTime? timestamp,
    MessageStatus? status,
    bool? isDeleted,
    bool? isForwarded,
    String? replyToId,
  }) {
    return Message(
      id: id ?? this.id,
      chatId: chatId ?? this.chatId,
      senderId: senderId ?? this.senderId,
      receiverId: receiverId ?? this.receiverId,
      type: type ?? this.type,
      content: content ?? this.content,
      filePath: filePath ?? this.filePath,
      fileSize: fileSize ?? this.fileSize,
      thumbnailPath: thumbnailPath ?? this.thumbnailPath,
      timestamp: timestamp ?? this.timestamp,
      status: status ?? this.status,
      isDeleted: isDeleted ?? this.isDeleted,
      isForwarded: isForwarded ?? this.isForwarded,
      replyToId: replyToId ?? this.replyToId,
    );
  }
  
  Map<String, dynamic> toJson() => {
    'id': id,
    'chatId': chatId,
    'senderId': senderId,
    'receiverId': receiverId,
    'type': type.index,
    'content': content,
    'filePath': filePath,
    'fileSize': fileSize,
    'thumbnailPath': thumbnailPath,
    'timestamp': timestamp.toIso8601String(),
    'status': status.index,
    'isDeleted': isDeleted,
    'isForwarded': isForwarded,
    'replyToId': replyToId,
  };
  
  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: json['id'],
      chatId: json['chatId'],
      senderId: json['senderId'],
      receiverId: json['receiverId'],
      type: MessageType.values[json['type']],
      content: json['content'],
      filePath: json['filePath'],
      fileSize: json['fileSize'],
      thumbnailPath: json['thumbnailPath'],
      timestamp: DateTime.parse(json['timestamp']),
      status: MessageStatus.values[json['status']],
      isDeleted: json['isDeleted'] ?? false,
      isForwarded: json['isForwarded'] ?? false,
      replyToId: json['replyToId'],
    );
  }
  
  bool get isText => type == MessageType.text;
  bool get isFile => type == MessageType.file || 
                      type == MessageType.image || 
                      type == MessageType.video || 
                      type == MessageType.audio;
}
