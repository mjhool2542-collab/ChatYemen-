import 'package:equatable/equatable.dart';

class User extends Equatable {
  final String id;
  final String name;
  final String? avatarPath;
  final bool isOnline;
  final String? ipAddress;
  final int? port;
  final String? publicKey;
  final DateTime? lastSeen;
  
  const User({
    required this.id,
    required this.name,
    this.avatarPath,
    this.isOnline = false,
    this.ipAddress,
    this.port,
    this.publicKey,
    this.lastSeen,
  });
  
  @override
  List<Object?> get props => [
    id, name, avatarPath, isOnline, ipAddress, port, publicKey, lastSeen
  ];
  
  User copyWith({
    String? id,
    String? name,
    String? avatarPath,
    bool? isOnline,
    String? ipAddress,
    int? port,
    String? publicKey,
    DateTime? lastSeen,
  }) {
    return User(
      id: id ?? this.id,
      name: name ?? this.name,
      avatarPath: avatarPath ?? this.avatarPath,
      isOnline: isOnline ?? this.isOnline,
      ipAddress: ipAddress ?? this.ipAddress,
      port: port ?? this.port,
      publicKey: publicKey ?? this.publicKey,
      lastSeen: lastSeen ?? this.lastSeen,
    );
  }
  
  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'avatarPath': avatarPath,
    'isOnline': isOnline,
    'ipAddress': ipAddress,
    'port': port,
    'publicKey': publicKey,
    'lastSeen': lastSeen?.toIso8601String(),
  };
  
  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      name: json['name'],
      avatarPath: json['avatarPath'],
      isOnline: json['isOnline'] ?? false,
      ipAddress: json['ipAddress'],
      port: json['port'],
      publicKey: json['publicKey'],
      lastSeen: json['lastSeen'] != null 
          ? DateTime.parse(json['lastSeen']) 
          : null,
    );
  }
}
