import 'package:flutter/material.dart';

class AppColors {
  // ألوان العلم اليمني
  static const Color primary = Color(0xFF078C4A);    // أخضر
  static const Color secondary = Color(0xFFCE1126);  // أحمر
  static const Color black = Color(0xFF000000);      // أسود
  
  // الوضع الفاتح
  static const Color lightBackground = Colors.white;
  static const Color lightMyMessage = Color(0xFFDCF8C6);
  static const Color lightOtherMessage = Color(0xFFE4E6EB);
  static const Color lightText = Color(0xFF1F1F1F);
  static const Color lightHint = Color(0xFF9E9E9E);
  
  // الوضع الداكن
  static const Color darkBackground = Color(0xFF121212);
  static const Color darkSurface = Color(0xFF1E1E1E);
  static const Color darkMyMessage = Color(0xFF054740);
  static const Color darkOtherMessage = Color(0xFF2A2A2A);
  static const Color darkText = Color(0xFFE0E0E0);
  
  // حالات
  static const Color online = Color(0xFF4CAF50);
  static const Color offline = Color(0xFF9E9E9E);
  static const Color error = Color(0xFFF44336);
  static const Color success = Color(0xFF4CAF50);
  
  // ظلال
  static const Color shadow = Color(0x1A000000);
}
