class AppConstants {
  // صناديق Hive
  static const String usersBox = 'users_box';
  static const String messagesBox = 'messages_box';
  static const String chatsBox = 'chats_box';
  static const String transfersBox = 'transfers_box';
  
  // إعدادات النقل (محسنة لتشبه Zapya)
  static const int chunkSize = 256 * 1024; // 256KB لسرعة أكبر
  static const int maxDirectTransfer = 2000 * 1024 * 1024; // 2GB لدعم ملفات ضخمة
  
  // إعدادات Mesh (مشابهة لـ Bridgefy)
  static const int maxMeshHops = 3; // عدد القفزات المسموح بها لتوصيل الرسالة
  static const bool enablePublicChannels = true; // دعم غرف الدردشة العامة مثل FireChat
  
  // المهلات (بالثواني)
  static const int connectionTimeout = 30;
  static const int discoveryTimeout = 60;
  
  // المنفذ الافتراضي
  static const int defaultPort = 8080;
  
  // اسم التطبيق
  static const String appName = 'ChatYemen';
  static const String appVersion = '1.0.0';
}
