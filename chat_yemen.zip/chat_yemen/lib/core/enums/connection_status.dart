import 'package:flutter/material.dart';
import 'package:chat_yemen/core/constants/app_colors.dart';

enum ConnectionStatus {
  disconnected,
  connecting,
  connected,
  error;
  
  bool get isConnected => this == ConnectionStatus.connected;
  bool get isConnecting => this == ConnectionStatus.connecting;
  bool get isDisconnected => this == ConnectionStatus.disconnected;
  
  String get message {
    switch (this) {
      case ConnectionStatus.disconnected:
        return 'غير متصل';
      case ConnectionStatus.connecting:
        return 'جاري الاتصال...';
      case ConnectionStatus.connected:
        return 'متصل ✅';
      case ConnectionStatus.error:
        return '⚠️ خطأ في الاتصال';
    }
  }
  
  Color get color {
    switch (this) {
      case ConnectionStatus.disconnected:
        return AppColors.offline;
      case ConnectionStatus.connecting:
        return AppColors.secondary;
      case ConnectionStatus.connected:
        return AppColors.online;
      case ConnectionStatus.error:
        return AppColors.error;
    }
  }
}
