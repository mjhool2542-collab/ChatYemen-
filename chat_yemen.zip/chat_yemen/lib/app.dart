import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:chat_yemen/core/constants/app_colors.dart';
import 'package:chat_yemen/presentation/providers/auth_provider.dart';
import 'package:chat_yemen/presentation/screens/identity_screen.dart';
import 'package:chat_yemen/presentation/screens/connections_screen.dart';

class ChatYemenApp extends ConsumerStatefulWidget {
  const ChatYemenApp({super.key});
  
  @override
  ConsumerState<ChatYemenApp> createState() => _ChatYemenAppState();
}

class _ChatYemenAppState extends ConsumerState<ChatYemenApp> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(authProvider.notifier).checkIdentity();
    });
  }
  
  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider);
    
    return MaterialApp(
      title: 'ChatYemen',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: AppColors.primary,
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primary,
          primary: AppColors.primary,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
        ),
      ),
      home: user == null 
          ? const IdentityScreen() 
          : const ConnectionsScreen(),
    );
  }
}
