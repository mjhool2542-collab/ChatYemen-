import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:chat_yemen/core/constants/app_constants.dart';
import 'package:chat_yemen/app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // طلب الأذونات
  await _requestPermissions();
  
  // تهيئة Hive
  await Hive.initFlutter();
  await Hive.openBox(AppConstants.usersBox);
  await Hive.openBox(AppConstants.messagesBox);
  await Hive.openBox(AppConstants.chatsBox);
  await Hive.openBox(AppConstants.transfersBox);
  
  runApp(
    const ProviderScope(
      child: ChatYemenApp(),
    ),
  );
}

Future<void> _requestPermissions() async {
  final permissions = [
    Permission.location,
    Permission.storage,
    Permission.camera,
    Permission.microphone,
    Permission.nearbyWifiDevices,
  ];
  
  await permissions.request();
}
